-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: bdproyectog2
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `compra`
--

DROP TABLE IF EXISTS `compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compra` (
  `cod_compra` int NOT NULL AUTO_INCREMENT,
  `Fecha_Compra` date DEFAULT NULL,
  `Costo_total_Compra` int DEFAULT NULL,
  PRIMARY KEY (`cod_compra`)
) ENGINE=InnoDB AUTO_INCREMENT=222222223 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compra`
--

LOCK TABLES `compra` WRITE;
/*!40000 ALTER TABLE `compra` DISABLE KEYS */;
INSERT INTO `compra` VALUES (1,'2024-06-11',1000),(2,'2024-06-11',1000),(3,'2024-06-11',1000),(10,'2024-06-11',10000),(80,'2024-06-11',0),(202,'2024-06-11',0),(972,'2024-06-11',2468864),(1002,'2024-06-11',0),(1220,'2024-06-11',0),(22222,'2024-06-11',0),(122322,'2024-06-11',0),(222123,'2024-06-11',2990),(12234543,'2024-06-11',20000),(222222222,'2024-06-11',0);
/*!40000 ALTER TABLE `compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compran`
--

DROP TABLE IF EXISTS `compran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compran` (
  `Cod_compra` int DEFAULT NULL,
  `Cod_producto` varchar(30) DEFAULT NULL,
  KEY `rrCod_compra_idx` (`Cod_compra`),
  KEY `rCod_producto_idx` (`Cod_producto`),
  CONSTRAINT `rCod_producto` FOREIGN KEY (`Cod_producto`) REFERENCES `producto` (`Cod_producto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rrCod_compra` FOREIGN KEY (`Cod_compra`) REFERENCES `compra` (`cod_compra`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compran`
--

LOCK TABLES `compran` WRITE;
/*!40000 ALTER TABLE `compran` DISABLE KEYS */;
/*!40000 ALTER TABLE `compran` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_venta`
--

DROP TABLE IF EXISTS `item_venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_venta` (
  `Cod_item_venta` int NOT NULL AUTO_INCREMENT,
  `Precio_venta_producto` int DEFAULT NULL,
  `Cantidad_producto_vendido` int DEFAULT NULL,
  `subtotal_venta` int DEFAULT NULL,
  `Cod_producto` varchar(30) DEFAULT NULL,
  `cod_venta` int DEFAULT NULL,
  PRIMARY KEY (`Cod_item_venta`),
  KEY `rrCod_producto_idx` (`Cod_producto`),
  KEY `rrcod_venta_idx` (`cod_venta`),
  CONSTRAINT `rcod_venta ` FOREIGN KEY (`cod_venta`) REFERENCES `ventas` (`cod_venta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rrCod_producto` FOREIGN KEY (`Cod_producto`) REFERENCES `producto` (`Cod_producto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_venta`
--

LOCK TABLES `item_venta` WRITE;
/*!40000 ALTER TABLE `item_venta` DISABLE KEYS */;
INSERT INTO `item_venta` VALUES (2,122,13,1586,'p1',1),(3,34,12,408,'p2',1);
/*!40000 ALTER TABLE `item_venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lotes_compra`
--

DROP TABLE IF EXISTS `lotes_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lotes_compra` (
  `ID_Lotes` int NOT NULL AUTO_INCREMENT,
  `Cod_Producto` varchar(30) DEFAULT NULL,
  `Fecha_Vencimiento` date DEFAULT NULL,
  `Cantidad_producto` int DEFAULT NULL,
  `Costo_unitario_Lote` int DEFAULT NULL,
  `Cod_compra` int DEFAULT NULL,
  PRIMARY KEY (`ID_Lotes`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lotes_compra`
--

LOCK TABLES `lotes_compra` WRITE;
/*!40000 ALTER TABLE `lotes_compra` DISABLE KEYS */;
INSERT INTO `lotes_compra` VALUES (1,'p4','2024-07-11',1000,2000,1),(2,'p5','2024-06-11',1000,2000,2),(3,'p6','2024-06-11',1000,2000,3),(4,'P5','2024-06-11',6,6,NULL),(5,'99989','2024-06-02',2,2,NULL),(12,'p1','2024-06-02',1,1,12209),(13,'p1','2024-06-02',1,1,10),(14,'p1','2024-06-02',1,1,80),(15,'p1','2024-06-02',1,1,80),(16,'p1','2024-06-02',1,1,80),(17,'p1','2024-06-02',1,1,202),(18,'p1','2024-06-02',1,1,1002),(19,'p1','2024-06-02',1,1,1220),(20,'p1','2024-06-02',1,1,22222),(21,'p1','2024-06-02',1,1,122322),(22,'p1','2024-06-02',1,1,222222222),(23,'p1','2024-06-02',1,1,12234543),(24,'p1','2024-06-02',1,1,12234543),(25,'p1','2024-06-02',1,1,12234543),(26,'p1','2024-06-02',1,1,222123),(27,'p1','2024-06-02',1,1,10),(28,'p1','2024-06-02',1,1,972),(29,'p1','2024-06-02',1,1,972);
/*!40000 ALTER TABLE `lotes_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producto`
--

DROP TABLE IF EXISTS `producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `producto` (
  `Cod_producto` varchar(30) NOT NULL,
  `cantidad_producto_stock` int DEFAULT NULL,
  `nombreProducto` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Cod_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto`
--

LOCK TABLES `producto` WRITE;
/*!40000 ALTER TABLE `producto` DISABLE KEYS */;
INSERT INTO `producto` VALUES ('10002',4,'casa'),('99989',4,'cloros'),('p1',120,'Producto 1'),('p2',100,'Producto 2'),('p3',103,'Producto 3'),('P5',118,'PRODUCTO 6');
/*!40000 ALTER TABLE `producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ventas`
--

DROP TABLE IF EXISTS `ventas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ventas` (
  `cod_venta` int NOT NULL AUTO_INCREMENT,
  `fecha_venta` date DEFAULT NULL,
  `total_venta` int DEFAULT NULL,
  PRIMARY KEY (`cod_venta`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventas`
--

LOCK TABLES `ventas` WRITE;
/*!40000 ALTER TABLE `ventas` DISABLE KEYS */;
INSERT INTO `ventas` VALUES (1,'2024-06-02',1994);
/*!40000 ALTER TABLE `ventas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-12  4:45:25
