﻿Imports MySql.Data.MySqlClient

Public Class ConexionBD

    Public con As New MySqlConnection("server=localhost;database=bdproyectog2;user=root;password=123456789;convert zero datetime=True") 'antes en vez de public estaba protected pero lo cambié a ver si así lograba mandar los registros

    'Función para conectarse a la base de datos
    Public Function conectar() As Boolean
        Try 'Cuando hablamos de transacciones debemos colocar try -catch para manejar excepciones.
            con.Open() ' usando la variable "con" llamamos al método Open de la clase MySQLConnection
            ' para abrir la conexión a la base de datos.
            'MsgBox("La conexión fue exitosa")
            Return True
        Catch ex As Exception 'Se ejecuta si existió alguna excepción o error durante la conexión.
            MsgBox(ex.Message) 'Para mostrar el error interno
            Return False
        End Try
    End Function

    'Procedimiento para desconectar la base de datos deje de utilizarse (por seguridad)
    Public Sub desconectar()
        Try 'Al ser una transacción con base de datos usamos try -catch para manejo de errores.
            If con.State = ConnectionState.Open Then ' Con una condición evaluamos si el estado de la conexión de la
                ' base de datos es abierta.

                con.Close() ' Si la condición se cumple, entonces usando la variable con, llamamos
                ' de la clase MySQLConnection para que cierre el acceso.
            End If
        Catch ex As Exception
            MsgBox(ex.Message) 'Muestra el mensaje al surgir un error o excepción.
        End Try
    End Sub


End Class
