﻿Imports System.Runtime.InteropServices.JavaScript.JSType

Public Class frmRegistroCompra


    Public subtotal1 As Integer = 0

    Private numeroFactura As Integer
    Private Sub frmRegistroCompra_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        numeroFactura = InputBox("Coloque el número de Factura ")
        Dim fechaActual As DateTime = DateTime.Today

    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles dtpComprap.ValueChanged

    End Sub
    Public Sub VerTotal()


        For Each item As String In liitems.Items
            Try
                Dim partes As String() = item.Split(" "c)

                Dim liiitemssubtotal As Integer = Integer.Parse(partes(5))
                'MsgBox(liiitemssubtotal)
                'MsgBox(partes(4))
                subtotal1 += liiitemssubtotal

            Catch ex As Exception
                MsgBox(ex.Message)

            End Try


        Next


        Dim itema As String = "Total " & subtotal1
        licompras.Items.Add(itema)
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim codigoProducto As String = txtcodigop.Text
        Dim nombre As String = txtNombrep.Text
        Dim fechaVencimiento As String = dtpComprap.Value.ToString("dd/MM/yyyy")
        Dim cantidad As Integer
        Dim subtotal As Integer

        Try
            cantidad = Integer.Parse(txtcantidad.Text)
            subtotal = Integer.Parse(txtsubTotal.Text)
        Catch ex As Exception
            MsgBox("Los valores dentro de Cantidad y Precio deben ser números")
            Exit Sub ' Salir de la función si ocurre un error en la conversión
        End Try

        If cantidad <= 0 Or subtotal <= 0 Then
            MsgBox("Las cantidades y el precio no pueden ser negativas")
            txtcantidad.Clear()
            txtsubTotal.Clear()
            Exit Sub ' Salir de la función si la cantidad o el subtotal son negativos o cero
        End If

        Dim validacionCodigoProducto As String = LimpiarTexto(codigoProducto)

        If validacionCodigoProducto = "valor nulo" Then
            MsgBox("Debe colocar un valor válido en el Código de Producto")
            Exit Sub ' Salir de la función si el código de producto es nulo
        End If

        ' Validar si el código de producto y el nombre existen en la tabla de productos
        Dim lote As New LoteCompra()
        Dim productoExistente As Boolean = lote.ValidarProductoExistente(codigoProducto, nombre)

        If Not productoExistente Then
            MsgBox("El producto no existe en la tabla de productos. Debe crear el producto primero.")
            Exit Sub ' Salir de la función si el producto no existe en la tabla de productos
        End If

        ' Si pasa todas las validaciones, agregar el ítem al listbox
        Dim item As String = $"{validacionCodigoProducto} {fechaVencimiento} {nombre} {cantidad} {subtotal}"
        liitems.Items.Add(item)
        txtcodigop.Clear()
        txtcantidad.Clear()
        txtsubTotal.Clear()
        txtNombrep.Clear()
    End Sub


    Private Function LimpiarTexto(texto As String) As String
        Dim textoLimpio As String = texto.Trim()
        If String.IsNullOrWhiteSpace(textoLimpio) Then
            Return "valor nulo"
        Else
            Return textoLimpio
        End If
    End Function


    Private Sub EliminarItem()

        Dim transaccionLiItems As String = TryCast(liitems.SelectedItem, String)
        Dim transaccionLiCompras As String = TryCast(licompras.SelectedItem, String)


        If transaccionLiItems IsNot Nothing Then
            Dim indexLiItems As Integer = liitems.Items.IndexOf(transaccionLiItems)
            If indexLiItems <> -1 Then
                liitems.Items.RemoveAt(indexLiItems)
                MsgBox("Se ha borrado con éxito " & transaccionLiItems)
                VerTotal()
                'Return

            End If
        Else
            MsgBox("Debe seleccionar primero la opción a eliminar desde transaccionLiItems ")

        End If


        If transaccionLiCompras IsNot Nothing Then
            Dim indexLiVentas As Integer = licompras.Items.IndexOf(transaccionLiCompras)
            If indexLiVentas <> -1 Then
                licompras.Items.RemoveAt(indexLiVentas)
                MsgBox("Se ha borrado con éxito " & transaccionLiCompras)
                VerTotal()
                'Return
            End If
        Else
            MsgBox("Debe seleccionar primero la opción a eliminar desde transaccionLiCompras ")

        End If



    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        EliminarItem()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        VerTotal()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim codigoProducto As String = txtcodigop.Text
        Dim cantidad As Integer
        Dim subtotal As Decimal
        Dim nombreProducto As String = txtNombrep.Text
        Dim fechaVencimiento As String = dtpComprap.Value.ToString("dd/MM/yyyy")

        Dim lote As New LoteCompra()
        ' Verificar si el código de producto ya existe en la lista de items
        Dim productoExistente As String = liitems.Items.Cast(Of String).FirstOrDefault(Function(item) item.StartsWith(codigoProducto))

        If productoExistente IsNot Nothing Then
            MsgBox("El producto con código " & codigoProducto & " ya existe en la lista.")
        Else
            ' Validar que la cantidad y el subtotal sean números válidos
            If Integer.TryParse(txtcantidad.Text, cantidad) AndAlso Decimal.TryParse(txtsubTotal.Text, subtotal) Then
                ' Agregar el nuevo producto a la lista de items
                lote.AgregarProducto(codigoProducto, nombreProducto, cantidad)
                Dim nuevoItem As String = $"{codigoProducto} {fechaVencimiento} {nombreProducto} {cantidad} {subtotal}"
                liitems.Items.Add(nuevoItem)

                ' Limpiar los campos de entrada
                txtcodigop.Clear()
                txtNombrep.Clear()
                txtcantidad.Clear()
                txtsubTotal.Clear()
                dtpComprap.Value = DateTime.Now

                MsgBox("Producto agregado con éxito.")
            Else
                MsgBox("La cantidad y el subtotal deben ser números válidos.")
            End If
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        'mandar la venta a la base de datos

        Dim lote As New LoteCompra With {
            .costoTotal = subtotal1
        }
        lote.VerificarYCrearCompra(numeroFactura)
        ' lote.Agregarlote(dtpventa.Value.ToString("dd/MM/yyyy"), total)
        'capturar el id de la venta en una variable
        ' Dim Id_venta As Integer = venta.obtener_cod_venta() 'antes estaba como Dim Id_venta As string = venta.obtener_cod_venta()
        'MsgBox("El codigo es " & Id_venta)

        'mandar cada uno de los items de venta a la BD con la variable que tiene el id de la venta como num venta
        For Each item As String In liitems.Items
            MsgBox("se a agregado el lote de forma exitosa")
            Try
                Dim partes As String() = item.Split(" "c)
                Dim Cod_Producto As String = partes(0)
                Dim Fecha_Vencimiento As String = partes(1)
                Dim Cantidad_producto As Integer = Integer.Parse(partes(3))
                Dim Costo_unitario_Lote As Integer = Cantidad_producto
                'MsgBox(Cod_Producto)
                'MsgBox(Fecha_Vencimiento)
                'MsgBox(Cantidad_producto)
                'MsgBox(Costo_unitario_Lote)
                'eliminar los productos del inventario
                '       obtener  cual es la cantidad de productos que hay de ese producto
                ' Dim cantidad_en_stock As Integer = venta.CantidadActual(cod_prod)
                '       nuevaCantidad= (productos que hay)-(cantidad que estoy quitando)
                ' Dim nuevaCantidad As Integer = cantidad_en_stock + cantidad

                'If nuevaCantidad <= 0 Then
                'MsgBox("Es importante que actualice su inventario en la base de datos o de manera física para el producto " & cod_prod)
                'End If
                '       UpdateProductos(nuevaCantidad,cod_prod)
                '  venta.updateCantidad(cod_prod, nuevaCantidad)
                '       update producto set cantidad_producto_stock= nuevaCantidad where cod_producto=codprod;


                '  Venta.AgregarItemVenta(precioventa, cantidad, subtotal, cod_prod, cod_venta)
                'MsgBox(precioventa & cantidad & subtotal & cod_prod & cod_venta)


                lote.Agregarlote(Cod_Producto, Fecha_Vencimiento, Cantidad_producto, Costo_unitario_Lote, numeroFactura)
            Catch ex As Exception
                MsgBox(ex.Message)

            End Try



        Next
        'eliminar los productos del inventario
        '       obtener  cual es la cantidad de productos que hay de ese producto
        '       nuevaCantidad= (productos que hay)-(cantidad que estoy quitando)
        '       UpdateProductos(nuevaCantidad,cod_prod)
        '       update producto set cantidad_producto_stock= (select  where cod_producto=codprod;




        '  LimpiarFInal()
    End Sub
    Public Sub LimpiarFInal()

        MsgBox("Venta finalizada y agregada a la base de datos")
        'txtpagaCon.Clear()

        Me.Close()
    End Sub

End Class