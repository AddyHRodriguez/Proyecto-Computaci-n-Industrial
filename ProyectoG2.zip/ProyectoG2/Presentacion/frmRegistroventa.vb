﻿Imports System.Data.SqlClient
Imports MySql.Data.MySqlClient
Imports Mysqlx

Public Class frmRegistroventa


    Public total As Integer = 0
    'Public fechastringBD As New String = dtpventa.Value.ToString("dd/MM/yyyy")



    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles btnaddtoDB.Click
        'mandar la venta a la base de datos

        Dim venta As New Venta()

        venta.AgregarVenta(dtpventa.Value, total)
        'capturar el id de la venta en una variable
        Dim Id_venta As Integer = venta.obtener_cod_venta() 'antes estaba como Dim Id_venta As string = venta.obtener_cod_venta()
        'MsgBox("El codigo es " & Id_venta)

        'mandar cada uno de los items de venta a la BD con la variable que tiene el id de la venta como num venta
        For Each item As String In liitems.Items
            Try
                Dim partes As String() = item.Split(" "c)

                Dim precioventa As Integer = Integer.Parse(partes(2))
                Dim cantidad As Integer = Integer.Parse(partes(1))
                Dim subtotal As Integer = Integer.Parse(partes(3))
                Dim cod_prod As String = partes(0)
                Dim cod_venta As Integer = Id_venta

                'eliminar los productos del inventario
                '       obtener  cual es la cantidad de productos que hay de ese producto
                Dim cantidad_en_stock As Integer = venta.CantidadActual(cod_prod)
                '       nuevaCantidad= (productos que hay)-(cantidad que estoy quitando)
                Dim nuevaCantidad As Integer = cantidad_en_stock - cantidad

                If nuevaCantidad <= 0 Then
                    MsgBox("Es importante que actualice su inventario en la base de datos o de manera física para el producto " & cod_prod)
                End If
                '       UpdateProductos(nuevaCantidad,cod_prod)
                venta.updateCantidad(cod_prod, nuevaCantidad)
                '       update producto set cantidad_producto_stock= nuevaCantidad where cod_producto=codprod;


                venta.AgregarItemVenta(precioventa, cantidad, subtotal, cod_prod, cod_venta)
                'MsgBox(precioventa & cantidad & subtotal & cod_prod & cod_venta)


            Catch ex As Exception
                MsgBox(ex.Message)

            End Try



        Next
        'eliminar los productos del inventario
        '       obtener  cual es la cantidad de productos que hay de ese producto
        '       nuevaCantidad= (productos que hay)-(cantidad que estoy quitando)
        '       UpdateProductos(nuevaCantidad,cod_prod)
        '       update producto set cantidad_producto_stock= (select  where cod_producto=codprod;




        LimpiarFInal()

    End Sub
    Public Sub LimpiarFInal()

        MsgBox("Venta finalizada y agregada a la base de datos")
        'txtpagaCon.Clear()

        Me.Close()


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        Dim codigoProducto As String = txtcodigop.Text
        Dim cantidad As New Integer
        Dim precio As New Integer
        Dim subtotal As New Integer

        Try

            cantidad = Integer.Parse(txtcantidad.Text)
            precio = Integer.Parse(txtprecio.Text)





        Catch ex As Exception
            MsgBox("Los valores dentro de Cantidad y Precio deben ser números")

        End Try

        If cantidad > 0 And precio > 0 Then




            subtotal = cantidad * precio




            Dim validacionCodigoProducto As String = LimpiarTexto(codigoProducto)

            Dim item As String = validacionCodigoProducto & " " & cantidad & " " & precio & " " & subtotal


            If validacionCodigoProducto <> "valor nulo" Then
                'hacer toda la operación para subir al listbox
                liitems.Items.Add(item)
                txtcodigop.Clear()
                txtcantidad.Clear()
                txtprecio.Clear()




            Else
                MsgBox("Debe de colocar un valor valido en el Código de Producto")
            End If
            'para que se actualice el total en el label
            VerTotal()
        Else
            MsgBox("Las cantidades y el precio no pueden ser negativas")
            txtcantidad.Clear()
            txtprecio.Clear()
        End If


    End Sub

    Private Function LimpiarTexto(texto As String) As String
        Dim textoLimpio As String = texto.Trim()
        If String.IsNullOrWhiteSpace(textoLimpio) Then
            Return "valor nulo"
        Else
            Return textoLimpio
        End If
    End Function



    'Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnvertotal.Click
    Public Sub VerTotal()
        total = 0


        For Each item As String In liitems.Items
            Try
                Dim partes As String() = item.Split(" "c)

                Dim liiitemssubtotal As Integer = Integer.Parse(partes(3))
                'MsgBox(liiitemssubtotal)
                'MsgBox(partes(4))
                total += liiitemssubtotal

            Catch ex As Exception
                MsgBox(ex.Message)

            End Try



        Next


        lbltotal.Text = "Total " & total.ToString("₵ 00 .00")
    End Sub

    Private Sub EliminarItem()

        Dim transaccionLiItems As String = TryCast(liitems.SelectedItem, String)
        Dim transaccionLiVentas As String = TryCast(liitems.SelectedItem, String)


        If transaccionLiItems IsNot Nothing Then
            Dim indexLiItems As Integer = liitems.Items.IndexOf(transaccionLiItems)
            If indexLiItems <> -1 Then
                liitems.Items.RemoveAt(indexLiItems)
                MsgBox("Se ha borrado con éxito " & transaccionLiItems)
                VerTotal()
                'Return

            End If
        Else
            MsgBox("Debe seleccionar primero la opción a eliminar desde transaccionLiItems ")

        End If


        If transaccionLiVentas IsNot Nothing Then
            Dim indexLiVentas As Integer = liventas.Items.IndexOf(transaccionLiVentas)
            If indexLiVentas <> -1 Then
                liventas.Items.RemoveAt(indexLiVentas)
                MsgBox("Se ha borrado con éxito " & transaccionLiVentas)
                VerTotal()
                'Return
            End If
        Else
            MsgBox("Debe seleccionar primero la opción a eliminar desde transaccionLiVentas ")

        End If



    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        EliminarItem()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles btnAgregarItem.Click
        Dim pagaCon As New Integer
        If total = 0 Then
            MsgBox("Asegurese de primero agregar Productos")
        Else
            Try
                pagaCon = Integer.Parse(txtpagaCon.Text)

                If pagaCon < 0 Then
                    MsgBox("Esto no puede ser una cantidad menor que cero")
                    txtpagaCon.Clear()
                Else
                    Dim vuelto As Integer = pagaCon - total

                    If vuelto >= 0 Then
                        'me aseguro que el liventas sólo tenga un item 
                        If liventas.Items.Count >= 1 Then
                            MsgBox("Sólo se puede agregar una venta por vez, si desea agregar otra, finalice la operación y comience de nuevo ")
                        Else
                            MsgBox("El total de la venta es " & total & " y su vuelto es de " & vuelto)
                            Dim fechastring As String = dtpventa.Value.ToString("dd/MM/yyyy")
                            liventas.Items.Add(total & " " & fechastring)
                            'liventas.Items.Add(fecha)
                        End If
                    Else
                        MsgBox("Cantidad insuficiente para adquirir los productos")

                    End If

                End If

            Catch ex As Exception
                MsgBox("Asegurese de colocar sólo números en este espacio")

            End Try

            'me aseguro que haya suficiente dinero antes de registrar la venta



        End If




    End Sub


End Class