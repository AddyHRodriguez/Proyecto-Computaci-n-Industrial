﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmConsultaProductos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        GroupBox1 = New GroupBox()
        Button3 = New Button()
        Button2 = New Button()
        Label3 = New Label()
        TextBox3 = New TextBox()
        Label2 = New Label()
        TextBox2 = New TextBox()
        Label1 = New Label()
        TextBox1 = New TextBox()
        Button1 = New Button()
        GroupBox2 = New GroupBox()
        Button5 = New Button()
        Label5 = New Label()
        TextBox5 = New TextBox()
        Label4 = New Label()
        TextBox4 = New TextBox()
        Button4 = New Button()
        Button7 = New Button()
        GroupBox1.SuspendLayout()
        GroupBox2.SuspendLayout()
        SuspendLayout()
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(Button3)
        GroupBox1.Controls.Add(Button2)
        GroupBox1.Controls.Add(Label3)
        GroupBox1.Controls.Add(TextBox3)
        GroupBox1.Controls.Add(Label2)
        GroupBox1.Controls.Add(TextBox2)
        GroupBox1.Controls.Add(Label1)
        GroupBox1.Controls.Add(TextBox1)
        GroupBox1.Controls.Add(Button1)
        GroupBox1.Location = New Point(12, 12)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(481, 338)
        GroupBox1.TabIndex = 0
        GroupBox1.TabStop = False
        GroupBox1.Text = "GroupBox1"
        ' 
        ' Button3
        ' 
        Button3.BackColor = SystemColors.GradientActiveCaption
        Button3.Font = New Font("Segoe UI", 9F, FontStyle.Bold)
        Button3.Location = New Point(320, 251)
        Button3.Name = "Button3"
        Button3.Size = New Size(141, 62)
        Button3.TabIndex = 9
        Button3.Text = "Actualizar Stock"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = SystemColors.GradientActiveCaption
        Button2.Font = New Font("Segoe UI", 9F, FontStyle.Bold)
        Button2.Location = New Point(320, 151)
        Button2.Name = "Button2"
        Button2.Size = New Size(141, 62)
        Button2.TabIndex = 8
        Button2.Text = "Eliminar Producto"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(8, 234)
        Label3.Name = "Label3"
        Label3.Size = New Size(238, 31)
        Label3.TabIndex = 7
        Label3.Text = "Cantidad Disponible "
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(9, 286)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(240, 27)
        TextBox3.TabIndex = 6
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(5, 134)
        Label2.Name = "Label2"
        Label2.Size = New Size(252, 31)
        Label2.TabIndex = 5
        Label2.Text = "Nombre del Producto "
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(6, 186)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(240, 27)
        TextBox2.TabIndex = 4
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(5, 38)
        Label1.Name = "Label1"
        Label1.Size = New Size(241, 31)
        Label1.TabIndex = 3
        Label1.Text = "Código del Producto "
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(6, 90)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(240, 27)
        TextBox1.TabIndex = 2
        ' 
        ' Button1
        ' 
        Button1.BackColor = SystemColors.GradientActiveCaption
        Button1.Font = New Font("Segoe UI", 9F, FontStyle.Bold)
        Button1.Location = New Point(320, 55)
        Button1.Name = "Button1"
        Button1.Size = New Size(141, 62)
        Button1.TabIndex = 1
        Button1.Text = "Consultar"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' GroupBox2
        ' 
        GroupBox2.Controls.Add(Button5)
        GroupBox2.Controls.Add(Label5)
        GroupBox2.Controls.Add(TextBox5)
        GroupBox2.Controls.Add(Label4)
        GroupBox2.Controls.Add(TextBox4)
        GroupBox2.Controls.Add(Button4)
        GroupBox2.Location = New Point(12, 367)
        GroupBox2.Name = "GroupBox2"
        GroupBox2.Size = New Size(481, 321)
        GroupBox2.TabIndex = 1
        GroupBox2.TabStop = False
        GroupBox2.Text = "GroupBox2"
        ' 
        ' Button5
        ' 
        Button5.BackColor = SystemColors.GradientActiveCaption
        Button5.Font = New Font("Segoe UI", 9F, FontStyle.Bold)
        Button5.Location = New Point(320, 170)
        Button5.Name = "Button5"
        Button5.Size = New Size(141, 62)
        Button5.TabIndex = 10
        Button5.Text = "Actualizar Fecha de vencimiento"
        Button5.UseVisualStyleBackColor = False
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(8, 134)
        Label5.Name = "Label5"
        Label5.Size = New Size(254, 31)
        Label5.TabIndex = 13
        Label5.Text = "Fecha de Vencimiento "
        ' 
        ' TextBox5
        ' 
        TextBox5.Location = New Point(17, 188)
        TextBox5.Name = "TextBox5"
        TextBox5.Size = New Size(240, 27)
        TextBox5.TabIndex = 12
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(34, 26)
        Label4.Name = "Label4"
        Label4.Size = New Size(212, 31)
        Label4.TabIndex = 11
        Label4.Text = "Identificador Lote "
        ' 
        ' TextBox4
        ' 
        TextBox4.Location = New Point(17, 75)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(240, 27)
        TextBox4.TabIndex = 10
        ' 
        ' Button4
        ' 
        Button4.BackColor = SystemColors.GradientActiveCaption
        Button4.Font = New Font("Segoe UI", 9F, FontStyle.Bold)
        Button4.Location = New Point(320, 57)
        Button4.Name = "Button4"
        Button4.Size = New Size(141, 62)
        Button4.TabIndex = 11
        Button4.Text = "Consultar Fecha de vencimiento"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' Button7
        ' 
        Button7.BackColor = SystemColors.GradientActiveCaption
        Button7.Font = New Font("Segoe UI", 9F, FontStyle.Bold)
        Button7.Location = New Point(824, 555)
        Button7.Name = "Button7"
        Button7.Size = New Size(177, 127)
        Button7.TabIndex = 10
        Button7.Text = "Generar Informe de Productos"
        Button7.UseVisualStyleBackColor = False
        ' 
        ' frmConsultaProductos
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.imagen_1
        ClientSize = New Size(1028, 700)
        Controls.Add(Button7)
        Controls.Add(GroupBox2)
        Controls.Add(GroupBox1)
        Name = "frmConsultaProductos"
        Text = "frmConsultaProductos"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        GroupBox2.ResumeLayout(False)
        GroupBox2.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Button7 As Button
End Class
