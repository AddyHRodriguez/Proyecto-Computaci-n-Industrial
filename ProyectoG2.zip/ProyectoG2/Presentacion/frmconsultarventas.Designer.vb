﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmconsultarventas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Button1 = New Button()
        GroupBox1 = New GroupBox()
        TextBox2 = New TextBox()
        Button2 = New Button()
        Label4 = New Label()
        Label2 = New Label()
        ListBox1 = New ListBox()
        Label1 = New Label()
        TextBox1 = New TextBox()
        GroupBox1.SuspendLayout()
        SuspendLayout()
        ' 
        ' Button1
        ' 
        Button1.BackColor = SystemColors.GradientActiveCaption
        Button1.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button1.Location = New Point(820, 471)
        Button1.Name = "Button1"
        Button1.Size = New Size(196, 115)
        Button1.TabIndex = 0
        Button1.Text = "Generar Informes de ventas"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' GroupBox1
        ' 
        GroupBox1.BackColor = SystemColors.GradientInactiveCaption
        GroupBox1.Controls.Add(TextBox2)
        GroupBox1.Controls.Add(Button2)
        GroupBox1.Controls.Add(Label4)
        GroupBox1.Controls.Add(Label2)
        GroupBox1.Controls.Add(ListBox1)
        GroupBox1.Controls.Add(Label1)
        GroupBox1.Controls.Add(TextBox1)
        GroupBox1.Location = New Point(12, 12)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(929, 426)
        GroupBox1.TabIndex = 1
        GroupBox1.TabStop = False
        GroupBox1.Text = "GroupBox1"
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(46, 343)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(213, 27)
        TextBox2.TabIndex = 8
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(46, 110)
        Button2.Name = "Button2"
        Button2.Size = New Size(213, 33)
        Button2.TabIndex = 7
        Button2.Text = "Buscar"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(313, 8)
        Label4.Name = "Label4"
        Label4.Size = New Size(274, 25)
        Label4.TabIndex = 6
        Label4.Text = "Visualizador de Items de Venta"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(23, 312)
        Label2.Name = "Label2"
        Label2.Size = New Size(265, 28)
        Label2.TabIndex = 4
        Label2.Text = "Total generado en la venta"
        ' 
        ' ListBox1
        ' 
        ListBox1.BackColor = SystemColors.ButtonHighlight
        ListBox1.FormattingEnabled = True
        ListBox1.Location = New Point(313, 36)
        ListBox1.Name = "ListBox1"
        ListBox1.Size = New Size(604, 304)
        ListBox1.TabIndex = 2
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(0, 23)
        Label1.Name = "Label1"
        Label1.Size = New Size(307, 28)
        Label1.TabIndex = 1
        Label1.Text = "Consultar por número de venta"
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(6, 67)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(301, 27)
        TextBox1.TabIndex = 0
        ' 
        ' frmconsultarventas
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.imagen_1
        ClientSize = New Size(1028, 700)
        Controls.Add(GroupBox1)
        Controls.Add(Button1)
        Name = "frmconsultarventas"
        Text = "frmconsultarventas"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents TextBox2 As TextBox
End Class
