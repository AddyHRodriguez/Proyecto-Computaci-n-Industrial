﻿Imports MySql.Data.MySqlClient

Public Class Venta

    Private conexion As New ConexionBD()

    'mandar la venta a la base de datos
    Public Sub AgregarVenta(fecha As Date, total As Integer)
        Try
            ' Conectar a la base de datos
            If conexion.conectar() Then
                ' Crear el comando SQL para insertar los registros
                Dim query As String = "INSERT INTO Ventas (fecha_venta, total_venta) VALUES (@fecha, @total)"

                ' Crear el comando
                Using command As New MySqlCommand(query, conexion.con)
                    ' Agregar los parámetros al comando
                    command.Parameters.AddWithValue("@fecha", fecha)
                    command.Parameters.AddWithValue("@total", total)

                    ' Ejecutar el comando
                    command.ExecuteNonQuery()

                End Using

                ' Desconectar de la base de datos
                conexion.desconectar()
            End If
        Catch ex As Exception
            ' Manejar errores
            MsgBox("Error al agregar el registro: " & ex.Message)
        End Try
    End Sub

    'capturar el id de la venta en una variable 
    Public Function obtener_cod_venta() As Integer
        Try
            ' Conectar a la base de datos
            If conexion.conectar() Then
                ' Crear el comando SQL para obtener el código de venta máximo
                Dim query As String = "SELECT MAX(cod_venta) FROM ventas"

                ' Crear el comando
                Using command As New MySqlCommand(query, conexion.con)
                    ' Ejecutar el comando y obtener el resultado
                    Dim result As Object = command.ExecuteScalar()

                    ' Desconectar de la base de datos
                    conexion.desconectar()

                    ' Convertir el resultado a entero y devolverlo
                    ' Asumimos que el valor no es nulo
                    Return Convert.ToInt32(result)
                End Using
            Else
                ' Manejar el caso en el que la conexión no se pudo establecer
                MsgBox("Error al conectar a la base de datos.")
                Return 0 ' Valor predeterminado en caso de fallo en la conexión
            End If
        Catch ex As Exception
            ' Manejar errores
            MsgBox("Error al procesar la información: " & ex.Message)
            Return 0 ' Valor predeterminado en caso de excepción
        End Try
    End Function

    Public Sub AgregarItemVenta(Precio_venta_producto As Integer, Cantidad_producto_vendido As Integer, subtotal_venta As Integer, Cod_producto As String, cod_venta As Integer)
        Try

            ' Conectar a la base de datos
            If conexion.conectar() Then
                ' Crear el comando SQL para insertar los registros
                Dim query As String = "INSERT INTO item_venta (Precio_venta_producto, Cantidad_producto_vendido, subtotal_venta, Cod_producto, cod_venta) VALUES (@precio, @cantidad,@subtotal,@codprod,@codventa)"

                ' Crear el comando
                Using command As New MySqlCommand(query, conexion.con)

                    command.Parameters.AddWithValue("@precio", Precio_venta_producto)
                    command.Parameters.AddWithValue("@cantidad", Cantidad_producto_vendido)
                    command.Parameters.AddWithValue("@subtotal", subtotal_venta)
                    command.Parameters.AddWithValue("@codprod", Cod_producto)
                    command.Parameters.AddWithValue("@codventa", cod_venta)



                    ' Ejecutar el comando
                    command.ExecuteNonQuery()


                    'MsgBox("Registro agregado exitosamente de items-------------.")
                End Using

                ' Desconectar de la base de datos
                conexion.desconectar()
            End If
        Catch ex As Exception
            ' Manejar errores
            MsgBox("Error al agregar el registro: " & ex.Message)
        End Try
    End Sub


    Public Sub updateCantidad(Codprod As String, cantprodActualizar As Integer)
        Try

            ' Conectar a la base de datos
            If conexion.conectar() Then
                ' Crear el comando SQL para insertar los registros

                Dim query As String = "update producto set cantidad_producto_stock= @cantprodActualizar where cod_producto=@codprod"

                ' Crear el comando
                Using command As New MySqlCommand(query, conexion.con)

                    command.Parameters.AddWithValue("@cantprodActualizar", cantprodActualizar)
                    command.Parameters.AddWithValue("@codprod", Codprod)




                    ' Ejecutar el comando
                    command.ExecuteNonQuery()


                    'MsgBox("Registro actualizado exitosamente de productos-------------.")
                End Using

                ' Desconectar de la base de datos
                conexion.desconectar()
            End If
        Catch ex As Exception
            ' Manejar errores
            MsgBox("Error al actualizar registros: " & ex.Message)
        End Try
    End Sub

    Public Function CantidadActual(codprod As String) As Integer
        Try
            ' Conectar a la base de datos
            If conexion.conectar() Then
                ' Crear el comando SQL para obtener el código de venta máximo
                Dim query As String = "SELECT cantidad_producto_stock FROM producto WHERE Cod_producto=@codProd"

                ' Crear el comando
                Using command As New MySqlCommand(query, conexion.con)

                    command.Parameters.AddWithValue("@codProd", codprod)


                    Dim result As Object = command.ExecuteScalar()



                    Return Convert.ToInt32(result)

                End Using
            Else
                ' Manejar el caso en el que la conexión no se pudo establecer
                MsgBox("Error al conectar a la base de datos.")
                Return 0 ' Valor predeterminado en caso de fallo en la conexión
            End If
        Catch ex As Exception
            ' Manejar errores
            MsgBox("Error al procesar la información: " & ex.Message)
            Return 0 ' Valor predeterminado en caso de excepción
        Finally
            ' Asegurar que la conexión se cierra
            If conexion.con.State = ConnectionState.Open Then
                conexion.desconectar()
            End If
        End Try
    End Function







End Class
