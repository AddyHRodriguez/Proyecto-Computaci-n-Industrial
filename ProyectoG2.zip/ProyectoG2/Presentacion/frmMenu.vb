﻿Imports MySql.Data.MySqlClient

Public Class frmMenu



    Private Sub frmMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim conectar As New ConexionBD
        conectar.conectar()
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        frmRegistroventa.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        frmRegistroCompra.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        frmConsultaProductos.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        frmconsultarventas.Show()
    End Sub
End Class
