﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRegistroventa
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        liitems = New ListBox()
        GroupBox1 = New GroupBox()
        dtpventa = New DateTimePicker()
        txtprecio = New TextBox()
        Label4 = New Label()
        txtcantidad = New TextBox()
        Label3 = New Label()
        lbltotal = New Label()
        btnEliminar = New Button()
        txtcodigop = New TextBox()
        btnAgregar = New Button()
        Label1 = New Label()
        GroupBox2 = New GroupBox()
        btnAgregarItem = New Button()
        txtpagaCon = New TextBox()
        Label5 = New Label()
        liventas = New ListBox()
        btnaddtoDB = New Button()
        GroupBox1.SuspendLayout()
        GroupBox2.SuspendLayout()
        SuspendLayout()
        ' 
        ' liitems
        ' 
        liitems.FormattingEnabled = True
        liitems.Location = New Point(12, 12)
        liitems.Name = "liitems"
        liitems.Size = New Size(371, 484)
        liitems.TabIndex = 0
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(dtpventa)
        GroupBox1.Controls.Add(txtprecio)
        GroupBox1.Controls.Add(Label4)
        GroupBox1.Controls.Add(txtcantidad)
        GroupBox1.Controls.Add(Label3)
        GroupBox1.Controls.Add(lbltotal)
        GroupBox1.Controls.Add(btnEliminar)
        GroupBox1.Controls.Add(txtcodigop)
        GroupBox1.Controls.Add(btnAgregar)
        GroupBox1.Controls.Add(Label1)
        GroupBox1.Location = New Point(389, 12)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(627, 342)
        GroupBox1.TabIndex = 1
        GroupBox1.TabStop = False
        GroupBox1.Text = "Agregar Productos"
        ' 
        ' dtpventa
        ' 
        dtpventa.CalendarFont = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        dtpventa.CalendarMonthBackground = SystemColors.InactiveCaption
        dtpventa.CalendarTitleBackColor = SystemColors.GradientInactiveCaption
        dtpventa.Font = New Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        dtpventa.Format = DateTimePickerFormat.Short
        dtpventa.Location = New Point(458, 17)
        dtpventa.Name = "dtpventa"
        dtpventa.Size = New Size(152, 27)
        dtpventa.TabIndex = 10
        dtpventa.Value = New Date(2024, 6, 2, 0, 0, 0, 0)
        ' 
        ' txtprecio
        ' 
        txtprecio.Location = New Point(418, 96)
        txtprecio.Name = "txtprecio"
        txtprecio.Size = New Size(125, 27)
        txtprecio.TabIndex = 8
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(445, 56)
        Label4.Name = "Label4"
        Label4.Size = New Size(71, 28)
        Label4.TabIndex = 7
        Label4.Text = "Precio"
        ' 
        ' txtcantidad
        ' 
        txtcantidad.Location = New Point(243, 96)
        txtcantidad.Name = "txtcantidad"
        txtcantidad.Size = New Size(125, 27)
        txtcantidad.TabIndex = 6
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(248, 56)
        Label3.Name = "Label3"
        Label3.Size = New Size(96, 28)
        Label3.TabIndex = 5
        Label3.Text = "Cantidad"
        ' 
        ' lbltotal
        ' 
        lbltotal.AutoSize = True
        lbltotal.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lbltotal.Location = New Point(392, 271)
        lbltotal.Name = "lbltotal"
        lbltotal.Size = New Size(227, 28)
        lbltotal.TabIndex = 4
        lbltotal.Text = "Puede ver aquí el total"
        ' 
        ' btnEliminar
        ' 
        btnEliminar.Font = New Font("Segoe UI", 10.8F, FontStyle.Bold)
        btnEliminar.Location = New Point(202, 251)
        btnEliminar.Name = "btnEliminar"
        btnEliminar.Size = New Size(184, 71)
        btnEliminar.TabIndex = 3
        btnEliminar.Text = "Eliminar "
        btnEliminar.UseVisualStyleBackColor = True
        ' 
        ' txtcodigop
        ' 
        txtcodigop.Location = New Point(18, 96)
        txtcodigop.Name = "txtcodigop"
        txtcodigop.Size = New Size(166, 27)
        txtcodigop.TabIndex = 2
        ' 
        ' btnAgregar
        ' 
        btnAgregar.Font = New Font("Segoe UI", 10.8F, FontStyle.Bold)
        btnAgregar.Location = New Point(11, 251)
        btnAgregar.Name = "btnAgregar"
        btnAgregar.Size = New Size(173, 71)
        btnAgregar.TabIndex = 1
        btnAgregar.Text = "Agregar"
        btnAgregar.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(0, 55)
        Label1.Name = "Label1"
        Label1.Size = New Size(199, 28)
        Label1.TabIndex = 0
        Label1.Text = "Código de Producto"
        ' 
        ' GroupBox2
        ' 
        GroupBox2.Controls.Add(btnAgregarItem)
        GroupBox2.Controls.Add(txtpagaCon)
        GroupBox2.Controls.Add(Label5)
        GroupBox2.Location = New Point(12, 502)
        GroupBox2.Name = "GroupBox2"
        GroupBox2.Size = New Size(371, 173)
        GroupBox2.TabIndex = 2
        GroupBox2.TabStop = False
        GroupBox2.Text = "Agregar ítem de ventas"
        ' 
        ' btnAgregarItem
        ' 
        btnAgregarItem.Location = New Point(208, 111)
        btnAgregarItem.Name = "btnAgregarItem"
        btnAgregarItem.Size = New Size(157, 46)
        btnAgregarItem.TabIndex = 5
        btnAgregarItem.Text = "Agregar Ítems"
        btnAgregarItem.UseVisualStyleBackColor = True
        ' 
        ' txtpagaCon
        ' 
        txtpagaCon.Location = New Point(55, 78)
        txtpagaCon.Name = "txtpagaCon"
        txtpagaCon.Size = New Size(258, 27)
        txtpagaCon.TabIndex = 1
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(0, 34)
        Label5.Name = "Label5"
        Label5.Size = New Size(373, 23)
        Label5.TabIndex = 0
        Label5.Text = "Coloque la Cantidad con la que está pagando"
        ' 
        ' liventas
        ' 
        liventas.FormattingEnabled = True
        liventas.Location = New Point(389, 372)
        liventas.Name = "liventas"
        liventas.Size = New Size(627, 124)
        liventas.TabIndex = 3
        ' 
        ' btnaddtoDB
        ' 
        btnaddtoDB.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnaddtoDB.Location = New Point(769, 536)
        btnaddtoDB.Name = "btnaddtoDB"
        btnaddtoDB.Size = New Size(213, 85)
        btnaddtoDB.TabIndex = 4
        btnaddtoDB.Text = "Terminar y Agregar Venta"
        btnaddtoDB.UseVisualStyleBackColor = True
        ' 
        ' frmRegistroventa
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.imagen_1
        ClientSize = New Size(1028, 700)
        Controls.Add(btnaddtoDB)
        Controls.Add(liventas)
        Controls.Add(GroupBox2)
        Controls.Add(GroupBox1)
        Controls.Add(liitems)
        Name = "frmRegistroventa"
        Text = "frmRegistroventa"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        GroupBox2.ResumeLayout(False)
        GroupBox2.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents liitems As ListBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtcodigop As TextBox
    Friend WithEvents btnAgregar As Button
    Friend WithEvents txtcantidad As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents lbltotal As Label
    Friend WithEvents btnEliminar As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents liventas As ListBox
    Friend WithEvents txtprecio As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btnaddtoDB As Button
    Friend WithEvents txtpagaCon As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents btnAgregarItem As Button
    Friend WithEvents dtpventa As DateTimePicker
End Class
