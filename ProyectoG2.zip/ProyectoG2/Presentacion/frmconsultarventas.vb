﻿Imports System.IO
Imports MySql.Data.MySqlClient

Public Class frmconsultarventas
    Private Sub frmconsultarventas_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' Llama a la función para buscar ítems de venta por código de venta
        BuscarItemVenta()
    End Sub

    Private Sub BuscarItemVenta()
        ' Crea una instancia de la clase de conexión
        Dim conexion As New ConexionBD()

        ' Abre la conexión
        If conexion.conectar() Then
            Try
                ' Obtiene el código de venta desde el TextBox1
                Dim codVenta As Integer = Integer.Parse(TextBox1.Text)

                ' Consulta SQL para obtener los datos de los ítems de venta relacionados al código de venta
                Dim query As String = "SELECT * FROM item_venta WHERE cod_venta = @cod_venta"
                Dim cmd As New MySqlCommand(query, conexion.con)

                ' Añade el parámetro de la consulta
                cmd.Parameters.AddWithValue("@cod_venta", codVenta)

                ' Ejecuta la consulta
                Dim reader As MySqlDataReader = cmd.ExecuteReader()

                ' Limpia el ListBox y el TextBox2
                ListBox1.Items.Clear()
                TextBox2.Clear()

                ' Inicializa la suma total
                Dim totalSum As Integer = 0

                ' Verifica si se encontraron ítems de venta
                If reader.HasRows Then
                    ' Procesa los resultados
                    While reader.Read()
                        ' Obtiene el subtotal de venta del ítem actual
                        Dim subtotalVenta As Integer = reader("subtotal_venta")

                        ' Suma el subtotal de venta al total
                        totalSum += subtotalVenta

                        ' Muestra los datos en ListBox1
                        ListBox1.Items.Add("------------------------------------------------------------")
                        ListBox1.Items.Add("Código: " & reader("Cod_item_venta").ToString())
                        ListBox1.Items.Add("Precio venta producto: " & reader("Precio_venta_producto").ToString())
                        ListBox1.Items.Add("Cantidad producto vendido: " & reader("Cantidad_producto_vendido").ToString())
                        ListBox1.Items.Add("Subtotal venta: " & reader("subtotal_venta").ToString())
                        ListBox1.Items.Add("Código producto: " & reader("Cod_producto").ToString())
                        ListBox1.Items.Add("Código venta: " & reader("cod_venta").ToString())
                        ListBox1.Items.Add("------------------------------------------------------------")
                    End While

                    ' Muestra el total en TextBox2
                    TextBox2.Text = totalSum.ToString()

                Else
                    ' Si no se encontró, muestra un mensaje
                    MessageBox.Show("No se encontraron ítems de venta con el código de venta especificado.")
                End If

                ' Cierra el reader
                reader.Close()

            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            Finally
                ' Cierra la conexión
                conexion.desconectar()
            End Try
        Else
            MessageBox.Show("No se pudo conectar a la base de datos.")
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Crear instancia de la conexión a la base de datos
        Dim conexion As New ConexionBD()

        ' Consulta SQL para obtener los datos de la tabla item_venta
        Dim queryItemVenta As String = "SELECT Cod_item_venta, Precio_venta_producto, Cantidad_producto_vendido, subtotal_venta, Cod_producto, cod_venta FROM item_venta"

        ' Ruta del archivo .txt
        Dim rutaArchivo As String = "C:\Users\User\Desktop\Documento de ventas.txt"

        Try
            ' Conectar a la base de datos
            If conexion.conectar() Then
                Using escritor As New StreamWriter(rutaArchivo, False)

                    ' Consultar datos de la tabla item_venta
                    Dim cmdItemVenta As New MySqlCommand(queryItemVenta, conexion.con)
                    Dim readerItemVenta As MySqlDataReader = cmdItemVenta.ExecuteReader()

                    ' Inicializar la suma total para todas las ventas
                    Dim totalSum As Integer = 0

                    ' Escribir datos de la tabla item_venta en el archivo con la estructura solicitada
                    While readerItemVenta.Read()
                        Dim subtotalVenta As Integer = readerItemVenta("subtotal_venta")
                        totalSum += subtotalVenta

                        escritor.WriteLine("------------------------------------------------------------")
                        escritor.WriteLine("Código: " & readerItemVenta("Cod_item_venta").ToString())
                        escritor.WriteLine("Precio venta producto: " & readerItemVenta("Precio_venta_producto").ToString())
                        escritor.WriteLine("Cantidad producto vendido: " & readerItemVenta("Cantidad_producto_vendido").ToString())
                        escritor.WriteLine("Subtotal venta: " & subtotalVenta.ToString())
                        escritor.WriteLine("Código producto: " & readerItemVenta("Cod_producto").ToString())
                        escritor.WriteLine("Código venta: " & readerItemVenta("cod_venta").ToString())
                        escritor.WriteLine("------------------------------------------------------------")
                    End While

                    ' Cierra el reader
                    readerItemVenta.Close()

                    ' Escribir el total de ventas en el archivo
                    escritor.WriteLine()
                    escritor.WriteLine("=====================================")
                    escritor.WriteLine("Total de las ventas: " & totalSum.ToString())
                    escritor.WriteLine("=====================================")

                    ' Confirmación
                    MsgBox("El archivo ha sido creado exitosamente en " & rutaArchivo)
                End Using

                ' Desconectar de la base de datos
                conexion.desconectar()
            Else
                MsgBox("Error al conectar a la base de datos.")
            End If

        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class