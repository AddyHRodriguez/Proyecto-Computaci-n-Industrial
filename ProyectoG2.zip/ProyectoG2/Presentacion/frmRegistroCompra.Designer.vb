﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmRegistroCompra
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        liitems = New ListBox()
        GroupBox1 = New GroupBox()
        Button5 = New Button()
        txtNombrep = New TextBox()
        Label5 = New Label()
        Button3 = New Button()
        Button2 = New Button()
        Label4 = New Label()
        dtpComprap = New DateTimePicker()
        txtsubTotal = New TextBox()
        Label3 = New Label()
        txtcantidad = New TextBox()
        txtcodigop = New TextBox()
        Label2 = New Label()
        Label1 = New Label()
        Button1 = New Button()
        licompras = New ListBox()
        Button4 = New Button()
        GroupBox1.SuspendLayout()
        SuspendLayout()
        ' 
        ' liitems
        ' 
        liitems.FormattingEnabled = True
        liitems.Location = New Point(12, 12)
        liitems.Name = "liitems"
        liitems.Size = New Size(346, 484)
        liitems.TabIndex = 0
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(Button5)
        GroupBox1.Controls.Add(txtNombrep)
        GroupBox1.Controls.Add(Label5)
        GroupBox1.Controls.Add(Button3)
        GroupBox1.Controls.Add(Button2)
        GroupBox1.Controls.Add(Label4)
        GroupBox1.Controls.Add(dtpComprap)
        GroupBox1.Controls.Add(txtsubTotal)
        GroupBox1.Controls.Add(Label3)
        GroupBox1.Controls.Add(txtcantidad)
        GroupBox1.Controls.Add(txtcodigop)
        GroupBox1.Controls.Add(Label2)
        GroupBox1.Controls.Add(Label1)
        GroupBox1.Controls.Add(Button1)
        GroupBox1.Location = New Point(364, 12)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(652, 484)
        GroupBox1.TabIndex = 1
        GroupBox1.TabStop = False
        GroupBox1.Text = "Registro por lotes"
        ' 
        ' Button5
        ' 
        Button5.BackColor = SystemColors.GradientInactiveCaption
        Button5.Font = New Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button5.Location = New Point(342, 360)
        Button5.Name = "Button5"
        Button5.Size = New Size(294, 104)
        Button5.TabIndex = 14
        Button5.Text = "Agregar Producto independiente de lote"
        Button5.UseVisualStyleBackColor = False
        ' 
        ' txtNombrep
        ' 
        txtNombrep.Location = New Point(32, 168)
        txtNombrep.Name = "txtNombrep"
        txtNombrep.Size = New Size(125, 27)
        txtNombrep.TabIndex = 13
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold)
        Label5.Location = New Point(6, 132)
        Label5.Name = "Label5"
        Label5.Size = New Size(185, 23)
        Label5.TabIndex = 12
        Label5.Text = "Nombre del producto"
        ' 
        ' Button3
        ' 
        Button3.BackColor = SystemColors.GradientInactiveCaption
        Button3.Font = New Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button3.Location = New Point(32, 360)
        Button3.Name = "Button3"
        Button3.Size = New Size(294, 104)
        Button3.TabIndex = 11
        Button3.Text = "Agregar Para Finalizar Operación"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(423, 245)
        Button2.Name = "Button2"
        Button2.Size = New Size(182, 56)
        Button2.TabIndex = 10
        Button2.Text = "Eliminar"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold)
        Label4.Location = New Point(442, 37)
        Label4.Name = "Label4"
        Label4.Size = New Size(184, 23)
        Label4.TabIndex = 9
        Label4.Text = "Fecha de Vencimiento"
        ' 
        ' dtpComprap
        ' 
        dtpComprap.Format = DateTimePickerFormat.Custom
        dtpComprap.Location = New Point(469, 78)
        dtpComprap.Name = "dtpComprap"
        dtpComprap.Size = New Size(115, 27)
        dtpComprap.TabIndex = 8
        dtpComprap.Value = New Date(2024, 6, 2, 0, 0, 0, 0)
        ' 
        ' txtsubTotal
        ' 
        txtsubTotal.Location = New Point(234, 168)
        txtsubTotal.Name = "txtsubTotal"
        txtsubTotal.Size = New Size(125, 27)
        txtsubTotal.TabIndex = 7
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold)
        Label3.Location = New Point(209, 132)
        Label3.Name = "Label3"
        Label3.Size = New Size(175, 23)
        Label3.TabIndex = 6
        Label3.Text = "Costo Unitario x lote"
        ' 
        ' txtcantidad
        ' 
        txtcantidad.Location = New Point(234, 78)
        txtcantidad.Name = "txtcantidad"
        txtcantidad.Size = New Size(125, 27)
        txtcantidad.TabIndex = 5
        ' 
        ' txtcodigop
        ' 
        txtcodigop.Location = New Point(32, 78)
        txtcodigop.Name = "txtcodigop"
        txtcodigop.Size = New Size(125, 27)
        txtcodigop.TabIndex = 3
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold)
        Label2.Location = New Point(253, 37)
        Label2.Name = "Label2"
        Label2.Size = New Size(83, 23)
        Label2.TabIndex = 2
        Label2.Text = "Cantidad"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold)
        Label1.Location = New Point(6, 37)
        Label1.Name = "Label1"
        Label1.Size = New Size(171, 23)
        Label1.TabIndex = 1
        Label1.Text = "Código de Producto"
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(218, 245)
        Button1.Name = "Button1"
        Button1.Size = New Size(182, 56)
        Button1.TabIndex = 0
        Button1.Text = "Agregar"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' licompras
        ' 
        licompras.FormattingEnabled = True
        licompras.Location = New Point(12, 502)
        licompras.Name = "licompras"
        licompras.Size = New Size(1004, 84)
        licompras.TabIndex = 2
        ' 
        ' Button4
        ' 
        Button4.BackColor = SystemColors.GradientActiveCaption
        Button4.Font = New Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button4.Location = New Point(759, 592)
        Button4.Name = "Button4"
        Button4.Size = New Size(257, 96)
        Button4.TabIndex = 12
        Button4.Text = "Confirmar y Finalizar Operación"
        Button4.UseVisualStyleBackColor = False
        ' 
        ' frmRegistroCompra
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.imagen_1
        ClientSize = New Size(1028, 700)
        Controls.Add(Button4)
        Controls.Add(licompras)
        Controls.Add(GroupBox1)
        Controls.Add(liitems)
        Name = "frmRegistroCompra"
        Text = "Registrar Compra"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents liitems As ListBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents txtcantidad As TextBox
    Friend WithEvents txtcodigop As TextBox
    Friend WithEvents txtsubTotal As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents dtpComprap As DateTimePicker
    Friend WithEvents Label4 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents licompras As ListBox
    Friend WithEvents Button4 As Button
    Friend WithEvents txtNombrep As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Button5 As Button
End Class
