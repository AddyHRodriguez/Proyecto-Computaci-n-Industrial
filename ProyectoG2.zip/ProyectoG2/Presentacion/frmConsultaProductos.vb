﻿Imports System.Data.SqlClient
Imports System.IO
Imports System.Reflection.Metadata
Imports MySql.Data.MySqlClient
Imports Mysqlx


Public Class frmConsultaProductos

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Crear instancia de la conexión a la base de datos
        Dim conexion As New ConexionBD()

        ' Declaración de variables para almacenar los datos recuperados
        Dim codigoProducto As String = TextBox1.Text
        Dim nombreProducto As String = String.Empty
        Dim cantidadDisponible As Integer = 0

        ' Cadena SQL para buscar el producto por el código
        Dim query As String = "SELECT Cod_producto, nombreProducto, cantidad_producto_stock FROM producto WHERE Cod_producto = @Cod_producto"

        ' Verificar que el TextBox1 no esté vacío
        If String.IsNullOrEmpty(codigoProducto) Then
            MsgBox("Por favor ingrese el código del producto.")
            Return
        End If

        Try
            ' Conectar a la base de datos
            If conexion.conectar() Then
                ' Crear un comando MySQL
                Dim cmd As New MySqlCommand(query, conexion.con)
                ' Parámetro para el código del producto
                cmd.Parameters.AddWithValue("@Cod_producto", codigoProducto)

                ' Ejecutar el comando y leer los resultados
                Dim reader As MySqlDataReader = cmd.ExecuteReader()

                ' Verificar si se obtuvieron resultados
                If reader.HasRows Then
                    ' Leer el resultado
                    While reader.Read()
                        ' Asignar los valores obtenidos a las variables
                        nombreProducto = reader("nombreProducto").ToString()
                        cantidadDisponible = Convert.ToInt32(reader("cantidad_producto_stock"))
                    End While

                    ' Mostrar los datos en los TextBox
                    TextBox2.Text = nombreProducto
                    TextBox3.Text = cantidadDisponible.ToString()
                Else
                    MsgBox("Producto no encontrado.")
                End If

                ' Cerrar el lector de datos
                reader.Close()
                ' Desconectar de la base de datos
                conexion.desconectar()
            Else
                MsgBox("Error al conectar a la base de datos.")
            End If

        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ' Crear instancia de la conexión a la base de datos
        Dim conexion As New ConexionBD()

        ' Obtener los valores de los TextBox
        Dim codigoProducto As String = TextBox1.Text
        Dim nombreProducto As String = TextBox2.Text
        Dim cantidadDisponible As String = TextBox3.Text

        ' Validar que los campos no estén vacíos
        If String.IsNullOrEmpty(codigoProducto) Or String.IsNullOrEmpty(nombreProducto) Or String.IsNullOrEmpty(cantidadDisponible) Then
            MsgBox("Por favor complete todos los campos antes de actualizar.")
            Return
        End If

        ' Validar que la cantidad sea un número
        Dim cantidad As Integer
        If Not Integer.TryParse(cantidadDisponible, cantidad) Then
            MsgBox("La cantidad debe ser un número válido.")
            Return
        End If

        ' Cadena SQL para actualizar el producto
        Dim query As String = "UPDATE producto SET nombreProducto = @nombreProducto, cantidad_producto_stock = @cantidad_producto_stock WHERE Cod_producto = @Cod_producto"

        Try
            ' Conectar a la base de datos
            If conexion.conectar() Then
                ' Crear un comando MySQL
                Dim cmd As New MySqlCommand(query, conexion.con)

                ' Asignar los valores a los parámetros
                cmd.Parameters.AddWithValue("@Cod_producto", codigoProducto)
                cmd.Parameters.AddWithValue("@nombreProducto", nombreProducto)
                cmd.Parameters.AddWithValue("@cantidad_producto_stock", cantidad)

                ' Ejecutar el comando de actualización
                Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                ' Verificar si la actualización fue exitosa
                If rowsAffected > 0 Then
                    MsgBox("El stock ha sido actualizado exitosamente.")
                Else
                    MsgBox("No se encontró el producto con el código especificado.")
                End If

                ' Desconectar de la base de datos
                conexion.desconectar()

                ' Limpiar los campos
                LimpiarCampos()
            Else
                MsgBox("Error al conectar a la base de datos.")
            End If

        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try
    End Sub
    Private Sub LimpiarCampos()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' Crear instancia de la conexión a la base de datos
        Dim conexion As New ConexionBD()

        ' Obtener los valores de los TextBox
        Dim codigoProducto As String = TextBox1.Text
        Dim nombreProducto As String = TextBox2.Text

        ' Validar que al menos uno de los campos no esté vacío
        If String.IsNullOrEmpty(codigoProducto) And String.IsNullOrEmpty(nombreProducto) Then
            MsgBox("Por favor ingrese el código o el nombre del producto para eliminar.")
            Return
        End If

        ' Construir la cadena SQL para eliminar el producto
        Dim query As String
        If Not String.IsNullOrEmpty(codigoProducto) Then
            query = "DELETE FROM producto WHERE Cod_producto = @Cod_producto"
        Else
            query = "DELETE FROM producto WHERE nombreProducto = @nombreProducto"
        End If

        Try
            ' Conectar a la base de datos
            If conexion.conectar() Then
                ' Crear un comando MySQL
                Dim cmd As New MySqlCommand(query, conexion.con)

                ' Asignar el valor al parámetro adecuado
                If Not String.IsNullOrEmpty(codigoProducto) Then
                    cmd.Parameters.AddWithValue("@Cod_producto", codigoProducto)
                Else
                    cmd.Parameters.AddWithValue("@nombreProducto", nombreProducto)
                End If

                ' Ejecutar el comando de eliminación
                Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                ' Verificar si la eliminación fue exitosa
                If rowsAffected > 0 Then
                    MsgBox("El producto ha sido eliminado exitosamente.")
                Else
                    MsgBox("No se encontró el producto con el código o nombre especificado.")
                End If

                ' Desconectar de la base de datos
                conexion.desconectar()

                ' Limpiar los campos
                LimpiarCampos()

            Else
                MsgBox("Error al conectar a la base de datos.")
            End If

        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try
    End Sub
    ' Evento Click del botón Consultar Lote
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        ' Crear instancia de la conexión a la base de datos
        Dim conexion As New ConexionBD()

        ' Obtener el valor del TextBox
        Dim ID_Lotes As String = TextBox4.Text

        ' Validar que el campo no esté vacío
        If String.IsNullOrEmpty(ID_Lotes) Then
            MsgBox("Por favor ingrese el identificador del lote.")
            Return
        End If

        ' Cadena SQL para buscar la fecha de vencimiento del lote
        Dim query As String = "SELECT Fecha_Vencimiento FROM lotes_compra WHERE ID_Lotes = @ID_Lotes"

        Try
            ' Conectar a la base de datos
            If conexion.conectar() Then
                ' Crear un comando MySQL
                Dim cmd As New MySqlCommand(query, conexion.con)
                ' Parámetro para el identificador del lote
                cmd.Parameters.AddWithValue("@ID_Lotes", ID_Lotes)

                ' Ejecutar el comando y leer los resultados
                Dim reader As MySqlDataReader = cmd.ExecuteReader()

                ' Verificar si se obtuvieron resultados
                If reader.HasRows Then
                    ' Leer el resultado
                    While reader.Read()
                        ' Mostrar la fecha de vencimiento en el TextBox
                        TextBox5.Text = Convert.ToDateTime(reader("Fecha_Vencimiento")).ToString("yyyy-MM-dd")
                    End While
                Else
                    MsgBox("Lote no encontrado.")
                End If

                ' Cerrar el lector de datos
                reader.Close()
                ' Desconectar de la base de datos
                conexion.desconectar()
            Else
                MsgBox("Error al conectar a la base de datos.")
            End If

        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        ' Crear instancia de la conexión a la base de datos
        Dim conexion As New ConexionBD()

        ' Obtener los valores de los TextBox
        Dim ID_Lotes As String = TextBox4.Text
        Dim nuevaFechaVencimiento As String = TextBox5.Text

        ' Validar que los campos no estén vacíos
        If String.IsNullOrEmpty(ID_Lotes) Or String.IsNullOrEmpty(nuevaFechaVencimiento) Then
            MsgBox("Por favor complete ambos campos antes de actualizar.")
            Return
        End If

        ' Validar que la nueva fecha sea una fecha válida
        Dim fecha As DateTime
        If Not DateTime.TryParse(nuevaFechaVencimiento, fecha) Then
            MsgBox("Ingrese una fecha válida en el formato yyyy-mm-dd.")
            Return
        End If

        ' Cadena SQL para actualizar la fecha de vencimiento del lote
        Dim query As String = "UPDATE lotes_compra SET Fecha_Vencimiento = @Fecha_Vencimiento WHERE ID_Lotes = @ID_Lotes"

        Try
            ' Conectar a la base de datos
            If conexion.conectar() Then
                ' Crear un comando MySQL
                Dim cmd As New MySqlCommand(query, conexion.con)

                ' Asignar los valores a los parámetros
                cmd.Parameters.AddWithValue("@ID_Lotes", ID_Lotes)
                cmd.Parameters.AddWithValue("@Fecha_Vencimiento", fecha.ToString("yyyy-MM-dd"))

                ' Ejecutar el comando de actualización
                Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                ' Verificar si la actualización fue exitosa
                If rowsAffected > 0 Then
                    MsgBox("La fecha de vencimiento ha sido actualizada exitosamente.")
                Else
                    MsgBox("No se encontró el lote con el identificador especificado.")
                End If

                ' Desconectar de la base de datos
                conexion.desconectar()

                ' Limpiar los campos
                LimpiarCamposLote()

            Else
                MsgBox("Error al conectar a la base de datos.")
            End If

        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try
    End Sub

    ' Procedimiento para limpiar los TextBox del lote
    Private Sub LimpiarCamposLote()
        TextBox4.Clear()
        TextBox5.Clear()
    End Sub

    ' Evento Click del botón para crear el archivo .txt
    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        ' Crear instancia de la conexión a la base de datos
        Dim conexion As New ConexionBD()

        ' Consultas SQL para obtener los datos de las tablas
        Dim queryProductos As String = "SELECT Cod_producto, nombreProducto, cantidad_producto_stock FROM producto"
        Dim queryLotesCompra As String = "SELECT ID_Lotes, Cod_Producto, Fecha_Vencimiento, Cantidad_producto, Costo_unitario_Lote FROM lotes_compra"

        ' Ruta del archivo .txt
        Dim rutaArchivo As String = "C:\Users\User\Desktop\Nuevo Documento de texto.txt"

        Try
            ' Conectar a la base de datos
            If conexion.conectar() Then
                Using escritor As New StreamWriter(rutaArchivo, False)

                    ' Consultar datos de la tabla producto
                    Dim cmdProductos As New MySqlCommand(queryProductos, conexion.con)
                    Dim readerProductos As MySqlDataReader = cmdProductos.ExecuteReader()

                    ' Escribir encabezado de la tabla producto
                    escritor.WriteLine("Tabla producto:")
                    escritor.WriteLine("---------------------------------------------------------")

                    ' Escribir datos de la tabla producto
                    While readerProductos.Read()
                        escritor.WriteLine("Código: " & readerProductos("Cod_producto").ToString())
                        escritor.WriteLine("Nombre Producto: " & readerProductos("nombreProducto").ToString())
                        escritor.WriteLine("Cantidad en Stock: " & readerProductos("cantidad_producto_stock").ToString())
                        escritor.WriteLine("---------------------------------------------------------")
                    End While
                    readerProductos.Close()
                    escritor.WriteLine()

                    ' Consultar datos de la tabla lotes_compra
                    Dim cmdLotesCompra As New MySqlCommand(queryLotesCompra, conexion.con)
                    Dim readerLotesCompra As MySqlDataReader = cmdLotesCompra.ExecuteReader()

                    ' Escribir encabezado de la tabla lotes_compra
                    escritor.WriteLine("Tabla lotes_compra:")
                    escritor.WriteLine("---------------------------------------------------------")

                    ' Escribir datos de la tabla lotes_compra
                    While readerLotesCompra.Read()
                        escritor.WriteLine("ID Lote: " & readerLotesCompra("ID_Lotes").ToString())
                        escritor.WriteLine("Código Producto: " & readerLotesCompra("Cod_Producto").ToString())
                        escritor.WriteLine("Fecha de Vencimiento: " & Convert.ToDateTime(readerLotesCompra("Fecha_Vencimiento")).ToString("yyyy-MM-dd"))
                        escritor.WriteLine("Cantidad del Producto: " & readerLotesCompra("Cantidad_producto").ToString())
                        escritor.WriteLine("Costo Unitario del Lote: " & readerLotesCompra("Costo_unitario_Lote").ToString())
                        escritor.WriteLine("---------------------------------------------------------")
                    End While
                    readerLotesCompra.Close()

                    ' Confirmación
                    MsgBox("El archivo ha sido creado exitosamente en " & rutaArchivo)
                End Using

                ' Desconectar de la base de datos
                conexion.desconectar()

            Else
                MsgBox("Error al conectar a la base de datos.")
            End If

        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try
    End Sub



    Private Sub frmConsultaProductos_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class