﻿Imports System.Transactions
Imports MySql.Data.MySqlClient
Imports Org.BouncyCastle.Math.EC

Public Class LoteCompra
    Private conexion As New ConexionBD()

    'Cantidad_producto  Costo_unitario_Lote Cod_compra
    Public costoTotal As Integer = 0

    Public Sub optenerNumero(num As Integer)
        costoTotal = num

    End Sub

    Public Sub AgregarProducto(codigo As String, nombre As String, cantidad As Integer)
        Try
            ' Conectar a la base de datos
            If conexion.conectar() Then
                ' Verificar si el producto ya existe en la base de datos
                Dim queryBuscar As String = "SELECT COUNT(*) FROM producto WHERE Cod_producto = @codigo OR nombreProducto = @nombre"

                Using commandBuscar As New MySqlCommand(queryBuscar, conexion.con)
                    commandBuscar.Parameters.AddWithValue("@codigo", codigo)

                    commandBuscar.Parameters.AddWithValue("@nombre", nombre)

                    Dim existeProducto As Integer = Convert.ToInt32(commandBuscar.ExecuteScalar())

                    If existeProducto > 0 Then
                        MsgBox("El producto ya existe en la base de datos.")
                        Return
                    End If
                End Using

                ' Crear el comando SQL para insertar el nuevo producto
                Dim queryInsertar As String = "INSERT INTO producto (Cod_producto,cantidad_producto_stock, nombreProducto) VALUES (@codigo,@cantidad, @nombre)"

                ' Crear el comando
                Using commandInsertar As New MySqlCommand(queryInsertar, conexion.con)
                    ' Agregar los parámetros al comando
                    commandInsertar.Parameters.AddWithValue("@codigo", codigo)
                    commandInsertar.Parameters.AddWithValue("@cantidad", cantidad)
                    commandInsertar.Parameters.AddWithValue("@nombre", nombre)

                    ' Ejecutar el comando
                    commandInsertar.ExecuteNonQuery()

                End Using

                ' Desconectar de la base de datos
                conexion.desconectar()
            End If
        Catch ex As Exception
            ' Manejar errores
            MsgBox("Error al agregar el producto: " & ex.Message)
        End Try
    End Sub


    Public Sub Agregarlote(Cod_Producto As String, Fecha_Vencimiento As Date, Cantidad_producto As Integer, Costo_unitario_Lote As Integer, numFactura As String)
        Try
            ' Conectar a la base de datos
            If conexion.conectar() Then
                ' Verificar si el producto ya existe en la tabla de productos
                Dim queryBuscarProducto As String = "SELECT COUNT(*) FROM producto WHERE Cod_producto = @Cod_Producto"
                Dim productoExistente As Integer

                Using commandBuscarProducto As New MySqlCommand(queryBuscarProducto, conexion.con)
                    commandBuscarProducto.Parameters.AddWithValue("@Cod_Producto", Cod_Producto)
                    productoExistente = Convert.ToInt32(commandBuscarProducto.ExecuteScalar())
                End Using

                If productoExistente > 0 Then
                    ' Si el producto existe, actualizar la cantidad en el inventario
                    Dim queryActualizarInventario As String = "UPDATE producto SET cantidad_producto_stock = cantidad_producto_stock + @Cantidad_producto WHERE Cod_Producto = @Cod_Producto"

                    Using commandActualizarInventario As New MySqlCommand(queryActualizarInventario, conexion.con)
                        commandActualizarInventario.Parameters.AddWithValue("@Cod_Producto", Cod_Producto)
                        commandActualizarInventario.Parameters.AddWithValue("@Cantidad_producto", Cantidad_producto)
                        commandActualizarInventario.ExecuteNonQuery()


                    End Using

                    ' Segunda consulta: Insertar en lotes_compra
                    Dim queryInsertarLote As String = "INSERT INTO lotes_compra (Cod_Producto, Fecha_Vencimiento, Cantidad_producto, Costo_unitario_Lote, Cod_compra) VALUES (@Cod_Producto, @Fecha_Vencimiento, @Cantidad_producto, @Costo_unitario_Lote, @numFactura)"
                    Using cmdInsertar As New MySqlCommand(queryInsertarLote, conexion.con)
                        cmdInsertar.Parameters.AddWithValue("@Cod_Producto", Cod_Producto)
                        cmdInsertar.Parameters.AddWithValue("@Fecha_Vencimiento", Fecha_Vencimiento)
                        cmdInsertar.Parameters.AddWithValue("@Cantidad_producto", Cantidad_producto)
                        cmdInsertar.Parameters.AddWithValue("@Costo_unitario_Lote", Costo_unitario_Lote)
                        cmdInsertar.Parameters.AddWithValue("@numFactura", numFactura)

                        cmdInsertar.ExecuteNonQuery()
                    End Using
                Else
                    ' Si el producto no existe, insertar un nuevo lote
                    Dim queryInsertarLote As String = "INSERT INTO lotes_compra (Cod_Producto, Fecha_Vencimiento, Cantidad_producto, Costo_unitario_Lote,Cod_compra) VALUES (@Cod_Producto, @Fecha_Vencimiento, @Cantidad_producto, @Costo_unitario_Lote,@numFactura)"

                    Using commandInsertarLote As New MySqlCommand(queryInsertarLote, conexion.con)
                        commandInsertarLote.Parameters.AddWithValue("@Cod_Producto", Cod_Producto)
                        commandInsertarLote.Parameters.AddWithValue("@Fecha_Vencimiento", Fecha_Vencimiento)
                        commandInsertarLote.Parameters.AddWithValue("@Cantidad_producto", Cantidad_producto)
                        commandInsertarLote.Parameters.AddWithValue("@Costo_unitario_Lote", Costo_unitario_Lote)
                        commandInsertarLote.Parameters.AddWithValue("@numFactura", numFactura)

                        commandInsertarLote.ExecuteNonQuery()
                    End Using
                End If

                ' Desconectar de la base de datos
                conexion.desconectar()
            End If
        Catch ex As Exception
            ' Manejar errores
            MsgBox("Error al agregar el lote: " & ex.Message)
        End Try
    End Sub
    Public Function ValidarProductoExistente(codigoProducto As String, nombre As String) As Boolean
        Try
            ' Conectar a la base de datos
            If conexion.conectar() Then
                ' Consultar si existe un producto con el código y nombre especificados
                Dim query As String = "SELECT COUNT(*) FROM producto WHERE Cod_Producto = @codigoProducto AND nombreproducto = @nombre"

                Using command As New MySqlCommand(query, conexion.con)
                    command.Parameters.AddWithValue("@codigoProducto", codigoProducto)
                    command.Parameters.AddWithValue("@nombre", nombre)

                    Dim resultado As Integer = Convert.ToInt32(command.ExecuteScalar())
                    Return resultado > 0 ' Devolver True si se encontró un producto con el código y nombre especificados, False si no se encontró
                End Using
            End If
        Catch ex As Exception
            ' Manejar errores
            MsgBox("Error al validar el producto existente: " & ex.Message)
        Finally
            ' Desconectar de la base de datos
            conexion.desconectar()
        End Try

        Return False ' Si hubo un error durante la validación, devolver False por precaución
    End Function

    Public Sub VerificarYCrearCompra(ByVal numeroFactura As Integer)
        ' Verificar si la factura ya existe en la tabla compra
        If Not FacturaExiste(numeroFactura) Then
            CrearCompra(numeroFactura)
        Else
            ActualizarCostoTotalCompra(numeroFactura, costoTotal)
        End If
    End Sub
    Private connectionString As String = "server=localhost;database=bdproyectog2;user=root;password=123456789;convert zero datetime=True"
    Private Function FacturaExiste(ByVal numeroFactura As Integer) As Boolean
        Dim existe As Boolean = False

        Using connection As New MySqlConnection(connectionString)
            Dim query As String = "SELECT COUNT(*) FROM compra WHERE cod_compra = @NumeroFactura"
            Using command As New MySqlCommand(query, connection)
                command.Parameters.AddWithValue("@NumeroFactura", numeroFactura)
                connection.Open()
                Dim count As Integer = Convert.ToInt32(command.ExecuteScalar())
                If count > 0 Then
                    existe = True
                End If
            End Using
        End Using

        Return existe
    End Function

    Private Sub CrearCompra(ByVal numeroFactura As Integer)
        Dim fechaActual As Date = Date.Today

        Using connection As New MySqlConnection(connectionString)
            Dim query As String = "INSERT INTO compra (cod_compra, Fecha_Compra, Costo_total_Compra) VALUES (@NumeroFactura, @FechaActual, @CostoTotal)"
            Using command As New MySqlCommand(query, connection)
                command.Parameters.AddWithValue("@NumeroFactura", numeroFactura)
                command.Parameters.AddWithValue("@FechaActual", fechaActual)
                command.Parameters.AddWithValue("@CostoTotal", costoTotal)
                connection.Open()
                command.ExecuteNonQuery()
            End Using
        End Using
    End Sub


    Private Sub ActualizarCostoTotalCompra(ByVal numeroFactura As Integer, ByVal costo As Integer)
        Using connection As New MySqlConnection(connectionString)
            Dim query As String = "UPDATE compra SET Costo_total_Compra = Costo_total_Compra + @Costo WHERE cod_compra = @NumeroFactura"
            Using command As New MySqlCommand(query, connection)
                command.Parameters.AddWithValue("@Costo", costo)
                command.Parameters.AddWithValue("@NumeroFactura", numeroFactura)
                connection.Open()
                command.ExecuteNonQuery()
            End Using
        End Using
    End Sub
End Class

